// Ready !

$(document).ready(function () {
    window.location.href = "skp:ladb_opencutlist_setup_dialog_context";
});