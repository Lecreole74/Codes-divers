module Ladb::OpenCutList

  require_relative '../../helper/part_drawing_helper'
  require_relative '../../helper/sanitizer_helper'
  require_relative '../common/common_write_definition_worker'
  require_relative '../common/common_process_drawing2d_worker'
  

  class CutlistProcessPartsWorker

    include PartDrawingHelper
    include SanitizerHelper

    def initialize(
      cutlist,
      processor_name: "default",
      part_ids: ,
      unit: Length::Millimeter,
      include_paths: false)

      @cutlist = cutlist
      @processor_name = processor_name
      @part_ids = part_ids
      @unit = unit
      @include_paths = include_paths
    end

    # -----

    def run
      return { :errors => [ 'default.error' ] } unless @cutlist
      return { :errors => [ 'tab.cutlist.error.obsolete_cutlist' ] } if @cutlist.obsolete?

      model = Sketchup.active_model
      return { :errors => [ 'tab.cutlist.error.no_model' ] } unless model

      # Retrieve part
      parts = @cutlist.get_real_parts(@part_ids)
      return { :errors => [ 'tab.cutlist.error.unknow_part' ] } if parts.empty?

      # Ask for output dir
      dir = UI.select_directory(title: PLUGIN.get_i18n_string('tab.cutlist.write.title'), directory: '')
      if dir
        folder_names = []
        folder_path = ""
        parts_with_sides = []
        errors_message =  []
        parts.select { |part| !part.virtual }.each do |part|
          # puts part.inspect
          # ************************************
          group = part.group
          folder_name = group.material_display_name
          folder_name = PLUGIN.get_i18n_string('tab.cutlist.material_undefined') if folder_name.nil? || folder_name.empty?
          folder_name += " - #{group.std_dimension}" unless group.std_dimension.empty?
          folder_name = _sanitize_filename(folder_name)
          folder_path = File.join(dir, folder_name)
          file_name = "#{part.number} - #{_sanitize_filename(part.name)}"
          # ********************************
          begin
            # ***********************
            unless folder_names.include?(folder_name)
              if File.exist?(folder_path)
                if UI.messagebox(PLUGIN.get_i18n_string('core.messagebox.dir_override', { :target => folder_name, :parent => File.basename(dir) }), MB_YESNO) == IDYES
                  FileUtils.remove_dir(folder_path, true)
                else
                  return { :cancelled => true }
                end
              end
              Dir.mkdir(folder_path)
              folder_names << folder_name
            end
            # *********************
            sides = { 
              side1:{}, 
              side2:{},
              side3:{},
              side4:{},
              side5:{},
              side6:{}
            }
            (1..6).each do |i|  
              side_number = i 
              drawing_def = _compute_part_drawing_def(side_number, part,
                                                      ignore_edges: !@include_paths,
                                                      origin_position: CommonDrawingDecompositionWorker::ORIGIN_POSITION_DEFAULT,
                                                      use_cache: !@include_paths
              )
              if drawing_def.is_a?(DrawingDef)
                response = CommonProcessDrawing2dWorker.new(
                  drawing_def, 
                    sides,
                    side_number,
                    unit: @unit
                  ).run
                if !response[:errors].nil? || response[:cancelled]
                  errors_message <<  [ 'core.error.failed_export_to', { :error => response[:errors] } ]  unless response[:errors].nil?
                end
              else
                errors_message <<  ['core.error.failed_export_to', {:error => "#{part.number} - #{part.name} - face #{side_number} - #{PLUGIN.get_i18n_string('tab.cutlist.error.unknow_part')}"} ]
              end
            end
              material_name = part.group.material_name
              material_name = PLUGIN.get_i18n_string('tab.cutlist.material_undefined') if material_name.nil? || material_name.empty?
              parts_with_sides << {
                :part => {:name => part.name, :number => part.number, :length => part.length, :width => part.width, :thickness => part.thickness, :material_name => material_name, :count => part.count, :content_layers => part.content_layers},
                :sides => sides,
                :folder_path => folder_path
              }
            rescue => e
            puts e.inspect
            puts e.backtrace
            return { :errors => [ [ 'core.error.failed_export_to', { :error => e.message } ] ] }
          end
        end

        relative_path = File.join(PLUGIN_DIR, 'posts', "#{@processor_name}.rb")
        if File.exist?(relative_path)
          load relative_path
          module_name = "#{@processor_name.capitalize}Processor"
          # Object.const_get(module_name)._execute_process(parts_with_sides, dir)
          Object.const_get(module_name)._execute_process(parts_with_sides)
        end
        return { :export_path => dir, :errors => errors_message  }
      end
    end
  end
end