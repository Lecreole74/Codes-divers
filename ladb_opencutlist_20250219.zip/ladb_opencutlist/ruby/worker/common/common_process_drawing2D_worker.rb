module Ladb::OpenCutList

  require_relative '../../constants'
  require_relative '../../helper/processor_process_helper'
  require_relative '../../model/drawing/drawing_def'
  require_relative '../../worker/common/common_drawing_projection_worker'

  class CommonProcessDrawing2dWorker

    include ProcessorProcessHelper

    def initialize(
      drawing_def,
      sides,
      side_number,
      unit: nil)
      @drawing_def = drawing_def
      @sides = sides
      @side_number = side_number
      @unit = unit
      # puts "\nside: #{@side_number}"
    end

    # -----

    def run
      return { :errors => [ 'default.error' ] } unless @drawing_def.is_a?(DrawingDef)

      begin

        # Compute projection
        projection_def = CommonDrawingProjectionWorker.new(@drawing_def,
          origin_position: CommonDrawingProjectionWorker::ORIGIN_POSITION_BOUNDS_MIN,
          merge_holes: true
        ).run
        
        if projection_def.is_a?(DrawingProjectionDef)

          _Process_to_object(projection_def)

          return { :sides => @sides }
        end
        return { :errors => [ 'default.error' ] }
      rescue => e
        puts e.inspect
        puts e.backtrace
        return { :errors => [ [ 'core.error.failed_export_to', { :error => e.message } ] ] }
      end
    end

    # -----

    private

    def _Process_to_object(projection_def)

      bounds = projection_def.bounds

      unit_sign, unit_factor = _processor_get_unit_sign_and_factor(@unit)
      unit_transformation = Geom::Transformation.scaling(unit_factor, unit_factor, 1.0)

      origin = Geom::Point3d.new(
        bounds.min.x,
        -(bounds.height + bounds.min.y)
      ).transform(unit_transformation)

      size = Geom::Point3d.new(
        bounds.width,
        bounds.height
      ).transform(unit_transformation)

      x = _processor_value(origin.x)
      y = _processor_value(origin.y)
      length = _processor_value(size.x)
      width = _processor_value(size.y)

      key_side = :"side#{@side_number}"
      # puts projection_def.layer_defs.inspect
      unless projection_def.layer_defs.empty?

      works = _processor_process_projection_def( projection_def,
                                  transformation: unit_transformation,
                                  unit_transformation: unit_transformation,
                                  unit_sign: unit_sign)
      @sides[key_side][:works] = works
      end
    end
  end
end