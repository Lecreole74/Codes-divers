module Ladb::OpenCutList

  class Controller

    @tab_name

    def initialize(tab_name)
      @tab_name = tab_name
    end

    def setup_commands
    end

    def setup_event_callbacks
    end

  end
end