module Ladb::OpenCutList

  module DefHelper

    def def
      @_def
    end

  end

end
