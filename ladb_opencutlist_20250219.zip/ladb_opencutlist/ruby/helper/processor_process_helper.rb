module Ladb::OpenCutList

  require_relative '../constants'

  module ProcessorProcessHelper

    def _processor_get_unit_sign_and_factor(unit)

      require_relative '../utils/dimension_utils'

      case unit
      when DimensionUtils::INCHES
        unit_factor = 1.0
        unit_sign = 'in'
      when DimensionUtils::CENTIMETER
        unit_factor = 1.0.to_l.to_cm
        unit_sign = 'cm'
      else
        unit_factor = 1.0.to_l.to_mm
        unit_sign = 'mm'
      end

      return unit_sign, unit_factor

    end

    def _processor_value(value)
      value.to_f.round(3)
    end

    def _processor_process_projection_def( projection_def,
                                  transformation: IDENTITY,
                                  unit_transformation: IDENTITY,
                                  unit_sign: '')

      require_relative '../model/drawing/drawing_projection_def'

      return unless projection_def.is_a?(DrawingProjectionDef)

      works = []
      # puts projection_def.layer_defs.inspect
      projection_def.layer_defs.sort_by { |v| [v.type_path? ? 1 : 0, v.depth ] }.each do |layer_def|   # Path's layers always on top

        layer_def.poly_defs.each do |poly_def|
          # puts poly_def.inspect
          if poly_def.curve_def

            if poly_def.curve_def.circle?

              portion = poly_def.curve_def.portions.first
              center = portion.ellipse_def.center
              radius = portion.ellipse_def.xradius

              center = Geom::Point3d.new(
                center.x,
                center.y
              ).transform(transformation)

              radius = Geom::Point3d.new(
                radius, 0
              ).transform(unit_transformation)

              depth = Geom::Point3d.new(
                layer_def.depth, 0).transform(unit_transformation)

              cx = _processor_value(center.x)
              cy = _processor_value(center.y)
              cz = _processor_value(depth.x)
              rx = _processor_value(radius.x)
              ccw = portion.ccw? ? 0 : 1
              
              # puts "HOLE > d: #{rx*2}#{unit_sign} p: #{-cz}#{unit_sign} ( #{cx}, cy: #{cy} )"
              works << {
                :type => "HOLE", 
                :cx => cx, 
                :cy => cy, 
                :cz => cz, 
                :rx => rx, 
                :ccw => ccw
              }

            else

              # Extract loop points from ordered edges and arc curves
              portion_setup = []

              depth = Geom::Point3d.new(layer_def.depth, 0).transform(unit_transformation)
              # puts "-----def:#{_processor_value(depth.x)}"
              poly_def.curve_def.portions.map.with_index { |portion, index|
                start_point = portion.start_point.transform(transformation)
                end_point = portion.end_point.transform(transformation)
                x = _processor_value(start_point.x)
                y = _processor_value(start_point.y)
                z = _processor_value(depth.x)
                if(index == 0)
                  # puts "START > x: #{x}, y: #{y}, z: #{z}"
                  portion_setup << {
                    :type => "L01",
                    :x => x, 
                    :y => y,
                    :z => z
                  }
                end

                if portion.is_a?(Geometrix::ArcCurvePortionDef)

                  radius = Geom::Point3d.new(
                    portion.ellipse_def.xradius,
                    portion.ellipse_def.yradius
                  ).transform(unit_transformation)

                  middle = portion.mid_point.transform(transformation)

                  rx = _processor_value(radius.x)
                  ry = _processor_value(radius.y)
                  xrot = -portion.ellipse_def.angle.radians.round(3)
                  lflag = 0
                  sflag = portion.ccw? ? 0 : 1
                  x1 = _processor_value(middle.x)
                  y1 = _processor_value(-middle.y)
                  x2 = _processor_value(end_point.x)
                  y2 = _processor_value(-end_point.y)
                  # puts "A01 > x2: #{x2}, y2: #{-y2} rx:#{rx} sflag: #{sflag} lflag: #{lflag} x1: #{x1} y1:#{y1} xrot: #{xrot}, depth: #{_processor_value(depth.x)}"
                  portion_setup << {
                    :type => "A01", 
                    :rx => rx,
                    :ry => ry,
                    :z => z, 
                    :xrot => xrot, 
                    :lflag => lflag, 
                    :sflag => sflag, 
                    :x1 => x1, 
                    :y1 => y1, 
                    :x2 => x2,
                    :y2 => -y2
                  }
                else
                  x = _processor_value(end_point.x)
                  y = _processor_value(end_point.y)
                  # puts "PATH > x: #{x}, y: #{y}, z: #{_processor_value(depth.x)}"
                  portion_setup << {
                    :type => "L01", 
                    :x => x, 
                    :y => y,
                    :z => z
                  }
                end     
              }
              works << { :type => "SETUP", :works => portion_setup }
            end
          end
        end
      end
      return works
    end
  end
end