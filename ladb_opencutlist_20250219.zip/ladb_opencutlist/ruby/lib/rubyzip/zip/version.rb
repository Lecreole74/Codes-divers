# frozen_string_literal: true

module Ladb::OpenCutList::Zip
  VERSION = '3.0.0.alpha'
end
