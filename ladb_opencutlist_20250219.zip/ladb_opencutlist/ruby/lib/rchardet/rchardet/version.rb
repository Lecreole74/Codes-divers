module Ladb::OpenCutList::CharDet
  VERSION = "1.8.0"
end
