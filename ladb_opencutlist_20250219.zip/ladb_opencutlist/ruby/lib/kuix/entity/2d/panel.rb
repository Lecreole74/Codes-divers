module Ladb::OpenCutList::Kuix

  class Panel < Entity2d

    def initialize(id = '')
      super(id)
    end

  end

end