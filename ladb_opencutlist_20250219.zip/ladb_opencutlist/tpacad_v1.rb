module TpacadProcessor
  @name = "Tpacad V1.0"
  @version = "1.0"
  @extension = "tcn"

  @index = 0

  def self._tcn_get_index
    @index += 1
  end

  # Fonction pour vérifier si un point est sur un segment
  def self.point_on_segment?(p, seg)
    (seg[0][0] <= p[0] && p[0] <= seg[1][0] || seg[1][0] <= p[0] && p[0] <= seg[0][0]) &&
    (seg[0][1] <= p[1] && p[1] <= seg[1][1] || seg[1][1] <= p[1] && p[1] <= seg[0][1])
  end

  # Fonction pour vérifier si une droite est sur le contour du rectangle
  def self.on_rectangle_contour?(point1, point2, segments)
    segments.any? do |seg|
      point_on_segment?(point1, seg) && point_on_segment?(point2, seg)
    end
  end

  def self._execute_process(parts_with_sides, dir)

    puts "Processor: #{@name} v#{@version}"
    puts "Dir: #{dir}"

    parts_with_sides.each do |part_with_sides|
      part = part_with_sides[:part]
      material_name = part[:material_name]
      sides = _reorder_sides_for_tpacad(part_with_sides[:sides])
      part_name = part[:name]
      part_number = part[:number]
      length = _tcn_value(part[:length])
      width = _tcn_value(part[:width])
      thickness = _tcn_value(part[:thickness])      

      filename = "#{part_name} - #{part_number} - #{material_name}"
      
      file_path = File.join(dir, "#{filename}.#{@extension}")
      puts "Filename: #{filename} length: #{length}, width: #{width}, thickness: #{thickness}"
      File.open(file_path, "w:ISO-8859-1") do |file|
        _write_tnc_file_start(file, length, width, thickness)
        side_numbers = [1, 3, 4, 5, 6]
        side_numbers.each do |face_number|
          # puts "\nFace #{face_number}"
          _write_side_start(file, face_number)
          _write_works(file, face_number, sides[:"side#{face_number}"], length, width, thickness) if !sides[:"side#{face_number}"].empty?
          _write_side_end(file)
        end
      end
    end
  end

  def self._reorder_sides_for_tpacad(ocl_sides)
  { side1: ocl_sides[:side2], side2: ocl_sides[:side1], side3: ocl_sides[:side6], side4: ocl_sides[:side4], side5: ocl_sides[:side5], side6: ocl_sides[:side3]}
  end

  def self._tcn_value(str)
    str.to_s.gsub(/[~\s]/, '').gsub(',', '.').to_f
  end

  def self._write_side_start(file, face_number)
    file.puts("SIDE##{face_number}{")
    file.puts('::DX=0 XY=1') if face_number != 1
  end

  def self._write_side_end(file)
    file.puts('}SIDE')
  end

  def self._get_infos()
    {:name => @name, :version => @version, :extension => @extension}
  end

  def self._write_tnc_file_start(file, length, width, thickness)
    file.puts('TPA\ALBATROS\EDICAD\02.00:1665:r0w0s1')
    file.puts('::SIDE=0;')
    file.puts('::ATTR=hide;varv')
    file.puts("::UNm DL=#{length} DH=#{width} DS=#{thickness}")
    file.puts("'tcn version=2.9.20")
    file.puts("'code=ansi'")
    file.puts('EXE{')
    file.puts('#0=0')
    file.puts('#1=0')
    file.puts('#2=0')
    file.puts('#3=0')
    file.puts('#4=0')
    file.puts('}EXE')
    file.puts('OFFS{')
    file.puts('#0=0.0|0')
    file.puts('#1=0.0|0')
    file.puts('#2=0.0|0')
    file.puts('}OFFS')
    file.puts('VARV{')
    file.puts('#0=0.0|0')
    file.puts('#1=0.0|0')
    file.puts('}VARV')
    file.puts('VAR{')
    file.puts('}VAR')
    file.puts('SPEC{')
    file.puts('}SPEC')
    file.puts('INFO{')
    file.puts('}INFO')
    file.puts('OPTI{')
    file.puts(':: OPTKIND=%;0 OPTROUTER=%;0 LSTCOD=%0%1%2')
    file.puts('}OPTI')
    file.puts('LINK{')
    file.puts('}LINK')
    file.puts('SIDE#0{')
    file.puts('W#1511{ ::WT2 WF=1  #8098=..\custom\mcr\fresatebarnesting.tmcr }W')
    file.puts('}SIDE')
  end

  def self._write_works(file, face_number, side, length, width, thickness)
    side[:works].each do |work|
      case work[:type]
      when 'HOLE'
        _write_hole(file, face_number, work, length, width, thickness)
      when 'SETUP'
        _write_setup(file, face_number, work[:works], length, width, thickness) if face_number == 1
      end
    end
  end

  def self._write_hole(file, face_number, hole, length, width, thickness)
    # puts "HOLE -> cx:#{hole[:cx]}, cy:#{hole[:cy]}, cz:#{hole[:cz]}, rx:#{hole[:rx]}(DIA:#{hole[:rx]*2} borgne:#{(face_number != 1 ||  (-hole[:cz].abs < thickness)) ? 0 : 1})"
    x, y = _tcn_symetrie_axe_vertical(hole[:cx], hole[:cy], length/2, width/2, face_number)
    z = -hole[:cz]
    d = hole[:rx]*2
    borgne = (face_number != 1 || (z.abs < thickness)) ? "0" : "1"
    index = _tcn_get_index
    # puts "index: #{index}"
    file.puts("W#81{ ::WTp WS=#{index}  #8015=0 #1=#{x.round(2)} #2=#{y.round(2)} #3=#{z} #1002=#{d.round(0)} #201=1 #203=1 #1001=#{borgne} #9505=0 }W")
  end

  def self._write_setup(file, face_number, works, length, width, thickness)
    index = 0
    ox = 0
    oy = 0
    oz = 0
    works.each do |work|
      # puts "index: #{index}"
      case work[:type]
      when "L01"
        x, y = _tcn_symetrie_axe_vertical(work[:x], work[:y], length/2, width/2, face_number)
        x = x.round(0)
        y = y.round(0)
        z = work[:z]
        p1 = [ox, oy]
        p2 = [x,y]
        rlength, rwidth = _get_real_length_and_width_by_side(length, width, thickness, face_number)
        # puts "Face: #{face_number} length: #{rlength}, width: #{rwidth}"
        rect = {
          a: [0, 0],
          b: [rlength, 0],
          c: [rlength, rwidth],
          d: [0, rwidth]
        }
        segments = [
          [rect[:a], rect[:b]], # segment AB
          [rect[:b], rect[:c]], # segment BC
          [rect[:c], rect[:d]], # segment CD
          [rect[:d], rect[:a]]  # segment DA
        ]
        isBordure = on_rectangle_contour?(p1, p2, segments)
        if !isBordure
          # file.puts("W#2201{ ::WTl  #8015=0 #8121=#{ox.round(2)} #8122=#{oy.round(2)} #8123=-#{oz} #1=#{x.round(2)} #2=#{y.round(2)} #3=-#{z} #42=0 #49=0 }W") if index == 1
          file.puts("W#2201{ ::WTl  #8015=0 #8121=#{ox.round(2)} #8122=#{oy.round(2)} #8123= #1=#{x.round(2)} #2=#{y.round(2)} #3= #42=0 #49=0 }W") if index == 1
          file.puts("W#2201{ ::WTl  #8015=0 #1=#{x.round(2)} #2=#{y.round(2)} #3= #42=0 #49=0 }W") if index > 1
        else
          index = 0
        end

        ox, oy, oz = [ x, y, z ]
      when "A01"
        x, y = _tcn_symetrie_axe_vertical(work[:x2], work[:y2], length/2, width/2, face_number)
        r = work[:rx]
        z = work[:z]
        sFlag = work[:sflag] == 0 ? "1" : "0"
        sFlag = work[:sflag] == 0 ? "0" : "1" if face_number == 4
        file.puts("W#2111{ ::WTa  #8015=0 #8121=#{ox.round(2)} #8122=#{oy.round(2)} #8123=-#{oz} #1=#{x.round(2)} #2=#{y.round(2)} #3=-#{z} #34=#{sFlag} #8017=#{r} #8050=0 #42=0 #49=0 }W") if index == 1
        file.puts("W#2111{ ::WTa  #8015=0 #1=#{x.round(2)} #2=#{y.round(2)} #3=-#{z} #34=#{sFlag} #8017=#{r} #8050=0 #42=0 #49=0 }W") if index > 1
        # puts "p1( #{ox}, #{oy} ), p2( #{x}, #{y} )"
        ox, oy, oz = [ x, y, z ]
      end
      index += 1
    end
  end

  def self._get_real_length_and_width_by_side(length, width, thickness, face_number)
    case face_number
    when 1,2
      return [length, width]
    when 3,5
      return [length, thickness]
    when 4,6
      return [width, thickness]
    end
  end


  def self._tcn_symetrie_axe_vertical(x, y, x_sym, y_sym, face_number)
    x_symetrique = 2 * x_sym - x
    y_symetrique = 2 * y_sym - x
    x_symetrique = y_symetrique if face_number == 4
    y = 2 * y_sym - y if face_number == 1
    ([1,3,4].include?(face_number)) ? [x_symetrique, y] : [x, y]
  end

  # def self._tcn_to_float(str)
  #   cleaned_str = str.gsub(/[^\d.]/, '')
  #   cleaned_str.to_f
  # end

end