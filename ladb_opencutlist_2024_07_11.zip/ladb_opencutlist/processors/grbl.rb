module GrblProcessor
  @name = "GRBL"
  @version = "1.1h"
  @extension = "gcode"
  def self._execute_process(processor_objects, dir)

    puts "#{@name} v#{@version}"
    puts "#{dir}"

  end

  def self._get_infos()
    return {:name => @name, :version => @version, :extension => @extension}
  end
end