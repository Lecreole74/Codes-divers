module DefaultProcessor
  @name = "Default"
  @version = "1.0"
  @extension = "xml"
  def self._execute_process(processor_objects, dir)

    puts "#{@name} v#{@version}"
    puts "#{dir}"

  end

  def self._get_infos()
    return {:name => @name, :version => @version, :extension => @extension}
  end
end