module TpacadProcessor
  @name = "Tpacad"
  @version = "1.0"
  @extension = "tcn"
  def self._execute_process(processor_objects, dir)

    puts "Processor: #{@name} v#{@version}"
    puts "Dir: #{dir}"
    processor_objects.each do |object|
      puts object
      part_name = object[:name]
      length = object[:length].to_f
      width = object[:width].to_f
      thickness = object[:thickness].to_f
      faces = object[:faces]
      # puts "#{part_name} (#{length} x #{width} x #{thickness})"
      # puts "#{object[:faces][:face1]}"
      name = _tcn_sanitize("#{part_name}_#{length}x#{width}x#{thickness}")
      file_path = File.join(dir, "#{name}.#{@extension}")
      File.open(file_path, "w:ISO-8859-1") do |file|
        _tcn_write_start(file, length, width,  thickness)
        _tcn_write_side1(file, faces[:face1])
        _tcn_write_side3(file, faces[:face3])
        _tcn_write_side4(file, faces[:face4])
        _tcn_write_side5(file, faces[:face5])
        _tcn_write_side6(file, faces[:face6])
      end
      # file_part.close
    end

  end

  def self._get_infos()
    return {:name => @name, :version => @version, :extension => @extension}
  end

  def self._tcn_write_start(file, length, width,  thickness)
    file.puts('TPA\ALBATROS\EDICAD\02.00:1665:r0w0s1')
    file.puts('::SIDE=0;')
    file.puts('::ATTR=hide;varv')
    file.puts("::UNm DL=#{length} DH=#{width} DS=#{thickness}")
    file.puts("'tcn version=2.9.20")
    file.puts("'code=ansi'")
    file.puts('EXE{')
    file.puts('#0=0')
    file.puts('#1=0')
    file.puts('#2=0')
    file.puts('#3=0')
    file.puts('#4=0')
    file.puts('}EXE')
    file.puts('OFFS{')
    file.puts('#0=0.0|0')
    file.puts('#1=0.0|0')
    file.puts('#2=0.0|0')
    file.puts('}OFFS')
    file.puts('VARV{')
    file.puts('#0=0.0|0')
    file.puts('#1=0.0|0')
    file.puts('}VARV')
    file.puts('VAR{')
    file.puts('}VAR')
    file.puts('SPEC{')
    file.puts('}SPEC')
    file.puts('INFO{')
    file.puts('}INFO')
    file.puts('OPTI{')
    file.puts(':: OPTKIND=%;0 OPTROUTER=%;0 LSTCOD=%0%1%2')
    file.puts('}OPTI')
    file.puts('LINK{')
    file.puts('}LINK')
    file.puts('SIDE#0{')
    file.puts('W#1511{ ::WT2 WF=1  #8098=..\custom\mcr\fresatebarnesting.tmcr }W')
    file.puts('}SIDE')
  end

  def self._tcn_write_side1(file, face)
    file.puts('SIDE#1{')
    _tcn_add_works(file, face[:works])
    file.puts('}SIDE')
  end

  def self._tcn_write_side3(file, face)
    file.puts('SIDE#3{')
    file.puts('::DX=0 XY=1')
    _tcn_add_works(file, face[:works])
    file.puts('}SIDE')
  end

  def self._tcn_write_side4(file, face)
    file.puts('SIDE#4{')
    file.puts('::DX=0 XY=1')
    _tcn_add_works(file, face[:works])
    file.puts('}SIDE')
  end

  def self._tcn_write_side5(file, face)
    file.puts('SIDE#5{')
    file.puts('::DX=0 XY=1')
    _tcn_add_works(file, face[:works])
    file.puts('}SIDE')
  end

  def self._tcn_write_side6(file, face)
    file.puts('SIDE#6{')
    file.puts('::DX=0 XY=1')
    _tcn_add_works(file, face[:works])
    file.puts('}SIDE')
  end

  def self._tcn_add_works(file, works)
    works.each do |work|
      case work[:type]
      when 'hole'
        _tcn_add_hole(file, work)
      end
    end
  end

  def self._tcn_add_hole(file, hole)
    x = hole[:x]
    y = hole[:y]
    z = hole[:z]
    d = hole[:r]*2
    file.puts("W#81{ ::WTp WS=1  #8015=0 #1=#{x} #2=#{y} #3=#{z} #1002=#{d} #201=1 #203=1 #1001=0 #9505=0 }W")
  end

  def self._tcn_sanitize(value)
    value.to_s.gsub(/[\s<>\/\\“:;?*|=‘.-]/, '_')
  end

end