module Ladb::OpenCutList::Kuix

  class Group < Entity3d

    def initialize(id = '')
      super(id)
    end

  end

end