module Ladb::OpenCutList

  require_relative '../../helper/part_drawing_helper'
  require_relative '../../helper/sanitizer_helper'
  require_relative '../common/common_write_definition_worker'
  require_relative '../common/common_process_drawing2d_worker'

  class CutlistProcessPartsWorker

    include PartDrawingHelper
    include SanitizerHelper

    def initialize(cutlist,
      processor_name: "default",
      part_ids: ,
      unit: Length::Millimeter,
      precision: 0,
      include_paths: false
    )

      @cutlist = cutlist
      @processor_name = processor_name
      @part_ids = part_ids
      @unit = unit
      @precision = precision
      @include_paths = include_paths
    end


    # -----

    def run
      return { :errors => [ 'default.error' ] } unless @cutlist
      return { :errors => [ 'tab.cutlist.error.obsolete_cutlist' ] } if @cutlist.obsolete?

      model = Sketchup.active_model
      return { :errors => [ 'tab.cutlist.error.no_model' ] } unless model

      # Retrieve part
      parts = @cutlist.get_real_parts(@part_ids)
      return { :errors => [ 'tab.cutlist.error.unknow_part' ] } if parts.empty?

      # Ask for output dir
      dir = UI.select_directory(title: PLUGIN.get_i18n_string('tab.cutlist.write.title'), directory: '')
      if dir
        processorObjects = []
        # folder_names = []
        parts.select { |part| !part.virtual }.each do |part|
          # puts part.thickness
          # puts "Nom: #{part.name}"
          # group = part.group
          # folder_name = group.material_display_name
          # folder_name = PLUGIN.get_i18n_string('tab.cutlist.material_undefined') if folder_name.nil? || folder_name.empty?
          # folder_name += " - #{group.std_dimension}" unless group.std_dimension.empty?
          # folder_name = _sanitize_filename(folder_name)
          # folder_path = File.join(dir, folder_name)
          # file_name = "#{part.number} - #{_sanitize_filename(part.name)}"

          begin

            # unless folder_names.include?(folder_name)
            #   if File.exist?(folder_path)
            #     if UI.messagebox(PLUGIN.get_i18n_string('core.messagebox.dir_override', { :target => folder_name, :parent => File.basename(dir) }), MB_YESNO) == IDYES
            #       FileUtils.remove_dir(folder_path, true)
            #     else
            #       return { :cancelled => true }
            #     end
            #   end
            #   Dir.mkdir(folder_path)
            #   folder_names << folder_name
            # end
            processorObject = { 
              face1:{}, 
              face2:{},
              face3:{},
              face4:{},
              face5:{},
              face6:{}
            }
            values = [1, 2, 6, 4, 3, 5]
            [1, 3, 4, 5, 6].each do |i|  
              face_number = values[i-1]
              # puts "Face #{face_number} (#{i}):"
              drawing_def = _compute_part_drawing_def(i, part,
                                                      ignore_edges: !@include_paths,
                                                      origin_position: CommonDrawingDecompositionWorker::ORIGIN_POSITION_DEFAULT,
                                                      use_cache: !@include_paths
              )
              return { :errors => [ 'tab.cutlist.error.unknow_part' ] } unless drawing_def.is_a?(DrawingDef)
              
              response = CommonProcessDrawing2dWorker.new(drawing_def, 
                processorObject,
                face_number,
                unit: @unit,
                precision: @precision
              ).run
              return response if !response[:errors].nil? || response[:cancelled]
            end
              # puts processorObject.inspect
              # puts "****** Fin part ******"
              processorObjects << {:name => part.name, :thickness => part.thickness, :length => part.length, :width => part.width, :faces => processorObject }
            rescue => e
            puts e.inspect
            puts e.backtrace
            return { :errors => [ [ 'core.error.failed_export_to', { :error => e.message } ] ] }
          end
        end
          relative_path = File.join(PLUGIN_DIR, 'processors', "#{@processor_name}.rb")
          if File.exist?(relative_path)
            load relative_path
            module_name = "#{@processor_name.capitalize}Processor"
            Object.const_get(module_name)._execute_process(processorObjects, dir)
            # _execute_process(processorObjects, dir)
          end
        return { :export_path => dir }
      end

    end

  end

end