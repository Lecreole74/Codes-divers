module Ladb::OpenCutList

  require_relative '../../constants'
  # require_relative '../../helper/dxf_writer_helper'
  require_relative '../../helper/processor_process_helper'
  require_relative '../../helper/sanitizer_helper'
  require_relative '../../utils/color_utils'
  require_relative '../../model/drawing/drawing_def'
  require_relative '../../worker/common/common_drawing_projection_worker'

  class CommonProcessDrawing2dWorker

    include ProcessorProcessHelper
    include SanitizerHelper

    def initialize(drawing_def,
                  processorObject,
                  face_number,
                  unit: nil,
                  precision: 0
    )

      @drawing_def = drawing_def
      @processorObject = processorObject
      @face_number = face_number
      @unit = unit
      @precision = precision
    end

    # -----

    def run
      return { :errors => [ 'default.error' ] } unless @drawing_def.is_a?(DrawingDef)

      begin

        # Compute projection
        projection_def = CommonDrawingProjectionWorker.new(@drawing_def,
          origin_position: CommonDrawingProjectionWorker::ORIGIN_POSITION_BOUNDS_MIN,
          merge_holes: true
        ).run
        
        if projection_def.is_a?(DrawingProjectionDef)

          _Process_to_object(projection_def)

          return { :processorObject => @processorObject }
        end
        return { :errors => [ 'default.error' ] }
      rescue => e
        puts e.inspect
        puts e.backtrace
        return { :errors => [ [ 'core.error.failed_export_to', { :error => e.message } ] ] }
      end
    end

    # -----

    private

    def _Process_to_object(projection_def)


      bounds = projection_def.bounds


      unit_sign, unit_factor = _processor_get_unit_sign_and_factor(@unit)
      unit_transformation = Geom::Transformation.scaling(unit_factor, unit_factor, 1.0)

      origin = Geom::Point3d.new(
        bounds.min.x,
        -(bounds.height + bounds.min.y)
      ).transform(unit_transformation)
      size = Geom::Point3d.new(
        bounds.width,
        bounds.height
      ).transform(unit_transformation)

      x = _processor_value(origin.x, @precision)
      y = _processor_value(origin.y, @precision)
      width = _processor_value(size.x, @precision)
      height = _processor_value(size.y, @precision)

      # puts "( face:#{@face_number} -> x:#{x}, y:#{y}, width:#{width}, height:#{height}, unit_sign:#{unit_sign})"
      key_face = :"face#{@face_number}"
      @processorObject[key_face][:info] = { width: width, height: height }
      # @processorObject[key_face][:works] = [{:val => 40}]
      unless projection_def.layer_defs.empty?


      works = _processor_process_projection_def( projection_def,
                                  transformation: unit_transformation,
                                  unit_transformation: unit_transformation,
                                  unit_sign: unit_sign,
                                  precision: @precision)
      @processorObject[key_face][:works] = works
      end
    end
  end
end